# Data dictionary and stable identities

All new JSON/JSONL/CSV files are UTF-8 with LF line endings. CSV array/object cells contain JSON. The provenance copies retain original encodings/formatting. Hash fields are lowercase SHA-256. Empty optional CSV cells mean unavailable/not applicable, not zero or a new category.

| File / field | Meaning |
|---|---|
| `dataset_registry.csv`: `dataset_id` | Permanent machine ID, e.g. `cdsab_hlr`; display names may be expanded without changing this ID |
| `legacy_name`, `legacy_dataset_id` | Mapping to the earlier papers/scripts; historical records keep their original identifiers |
| `literary_works.csv` | One row per component/book identity; Chinese titles and source author attribution, no invented publisher/edition |
| `literary_documents.csv` | Cross-component index of 585 evaluated literary views; **not 585 independent sources** |
| `doc_id` | Unchanged experimental document ID; unique across the four literary components |
| `source_id` | Parent excerpt/window; HLR lengths and external long/excerpt views share a source identity |
| `parent_doc_id` | Long view for a nested medium/short/excerpt; blank for the long view |
| `set_id`, `length` / `regime` | Declared group and length view, not an absolute token budget |
| `category_id`, `author_id`, `book_id` | Canonical source-relation identities, not latent semantic topic labels; not all external components have categories |
| `chapter_ids` | HLR/NFR/ELR-A use canonical strings; ELR-B uses original integers scoped by `book_id`. Compare chapters within the same book; do not join ELR-B chapter integers globally |
| `chapter_scope`, `chapter_kind`, `section_ids` | HLR distinctions between one/multiple chapters, numbered chapters and named sections; preserve multi-chapter records |
| `legacy_*` hierarchy fields | Earlier set-local labels retained for traceability; use canonical IDs for cross-set comparisons |
| `source_description`, `reference`, `validation_status`, `notes` | Original descriptive audit information; not independent similarity annotations. A path-valued reference denotes a source file, not a published bibliographic reference |
| `encoding`, `relative_path`, `source_file_sha256` | HLR original source decoding/path/byte identity |
| `text_sha256` | UTF-8 hash of the exact reconstructed **reader-level** document text, before encoder-specific whitespace/token normalization |
| `normalized_sha256` | Historical audit hash with its original normalization; not interchangeable with the byte or reader-level hash |
| `text_included` | Whether the derived scored text is directly in this public release (false). External raw source books are included separately |
| NFR `chapters` | Original source paths/hashes/headings and half-open character spans in the reconstructed fragment; excludes chapter headings from the scored body |
| ELR `source_url`, `ebook_id` | Original Project Gutenberg catalogue reference; `sources.csv` includes the exact download/hash |
| `prepared_text_checksums.json` | Exact prepared chapter/document/excerpt bytes, preserving differences such as a terminal LF. Reader-level `text_sha256` can legitimately differ |
| `queries.jsonl` | Original frozen candidate pools, including eligibility, task, regime/group and rotation where applicable |
| `qrels.csv`: `relevance` | 1=positive and 0=explicit evaluated negative. Omitted candidates are outside that pool, not assumed negatives |
| `query_eligible` | Exclude ineligible HLR queries from metrics; their audit records remain |
| Query identity | Composite `(dataset_id, task, group, rotation, query_id)`; the same text can participate in multiple distinct tasks/rotations |
| CAIL `triplet_id` | Original split and 1-based row; stable across derivatives |
| CAIL `source_line`, `output_line` | 1-based original and variant positions; `split` remains the original split |
| CAIL case IDs | SHA-256 of UTF-8 case text after removing Unicode whitespace only; A is the anchor, B and C candidates |
| CAIL `label` | Original literal `B` or `C`; no relabeling or AI-generated targets |
| `row_manifest.jsonl` | Original row identity, comparison identity and retention decisions for both derivatives |
| `*_cases.csv`: `splits` | Split memberships of each compact-normalized case text; only the case-disjoint derivative guarantees one split per case |

## Hierarchy and task definitions

HLR exposes cumulative `same_chapter`, `same_book`, `same_author` and `same_category` relationships in `pairs.jsonl` and the original conditional pair flags. Chapter sharing is set intersection **within canonical book identity**, allowing records that cover more than one section. More specific relationships generally imply broader ones; the flags are not four independent observations. Dynasty is **not a standardized field in this checked release** and is not an evaluated target; no dynasty labels were invented during repackaging.

The frozen HLR retrieval tasks are `chapter_within_book`, `book_within_author`, `author_within_category`, and `book_different_chapter`. The last excludes shared-chapter candidate pairs and uses different books by the same author as negatives. It has 18 eligible queries in each of nine set/length groups. Do not substitute all 405 documents as candidates.

NFR uses the other three fragments of the same novel as positives and all 32 fragments of other novels as negatives. External main task `other_book` uses the same definition within its declared pool: ELR-A has 3 positives/32 negatives; ELR-B has 3 positives/20 negatives in each held-out rotation. Additional same-author diagnostics remain in frozen query files and must be reported separately.

## Checksums and verification scope

`release_checksums.json` covers all distributed files except itself, `SHA256SUMS.txt` and bytecode caches; `SHA256SUMS.txt` additionally covers that manifest. Hashes detect accidental drift, not authenticity against a maliciously replaced manifest. The verifier rejects modified covered inputs, inconsistent qrels, wrong counts and cross-split exact-text case reuse in the derivative. Original release locks remain as provenance, separate from the new package's file hashes.
