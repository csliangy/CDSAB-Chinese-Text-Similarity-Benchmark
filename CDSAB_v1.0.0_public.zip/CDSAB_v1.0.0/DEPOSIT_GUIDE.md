# Deposit and paper citation

The package is prepared for upload; no repository record has been created or published by this workflow.

1. Create a dataset draft in Zenodo or your chosen archival repository. Use the title **Chinese Document Similarity and Alignment Benchmark (CDSAB)** and version **1.0.0**. Copy the description/keywords/rights breakdown from `deposit_metadata.json`. Confirm the dataset creator list (currently the manuscript's Liang Yang and Ningyuan Yang), contributions, affiliations and actual release date. No ORCID or DOI has been invented.
2. Upload `CDSAB_v1.0.0_public.zip` as the dataset artifact. If previews are useful, also upload the README and registry as separate files. Do not upload your private reconstruction directory as though the entire text corpus had the metadata license. The public archive's reproducibility boundary is described explicitly in its README.
3. Apply the mixed-rights statement in `LICENSES.md`. The metadata license covers the authors' original contributions; the 18 included unmodified Gutenberg files keep their embedded notices and terms. CAIL prose and copyrighted HLR/NFR narrative are excluded.
4. In Zenodo, [reserve a DOI while the record is still a draft](https://help.zenodo.org/docs/deposit/describe-records/reserve-doi/). Add the reserved dataset DOI to `CITATION.cff`, the `cdsab2026` entry in `dataset_references.bib` and manuscript `references.bib`, and the paper's Data availability paragraph. Use the **version-specific DOI** for this exact experimental release. Regenerate `release_checksums.json`/`SHA256SUMS.txt` only as the release maintainer after intentionally editing citation metadata; leave original source/protocol hashes untouched.
5. Add the eventual article DOI as a related identifier when available. Cite Xiao et al. (2019) for CAIL in addition to the CDSAB release citation. Cite the Gutenberg source records in the catalogue/metadata. The previously mentioned Figshare DOI does not by itself identify this corrected release; do not reuse it as a version identifier without verifying its deposited contents.
6. Verify the uploaded archive by downloading it and running `python scripts/verify_release.py`. Ensure the public record resolves before submitting the paper. Keep citation metadata consistent between the manuscript and deposited files.

Suggested final paper wording (fill only after deposit):

> The Chinese Document Similarity and Alignment Benchmark (CDSAB), version 1.0.0, is available at [version-specific DOI]. The release contains metadata, candidate pools, source hashes, construction protocols and reconstruction code. It includes 18 unmodified Project Gutenberg source books with their notices. HLR/NFR narrative and CAIL case prose require separately obtained source files; the supplied scripts validate those sources and recreate the evaluated views and CAIL derivatives. Original CAIL2019-SCM labels remain attributed to Xiao et al. (2019).

The current manuscript explicitly identifies the prepared release and marks its DOI as pending. It does not claim that an unpublished record is already accessible.
