# ELR-A: Chinese External Literary Retrieval A

Nine additional Project Gutenberg works, eight catalogue-author groups, 663 source chapters, 36 disjoint five-chapter long documents and 36 nested excerpts. Each excerpt is the first 1,500 nonspace characters of its window's first chapter, retaining internal whitespace. Whole chapter bodies are converted with OpenCC t2s 0.1.7 before sampling. The 18-source public collection includes these nine unmodified raw books with full upstream notices.

The initial frozen main task has 72 queries (36 per regime), each with 3 same-book positives/32 negatives. The 16 additional same-author diagnostic query records are separate: only the two Wu Jianren works support that diagnostic. Catalogue authorship is an operational grouping, not resolution of disputed attribution. Original target of eight authors with three works each was not achieved.

Corpus selection, source repairs and the change from 2,000 to 1,500 excerpt characters occurred before scoring. Exact/fingerprint overlap was checked against preceding inputs under declared thresholds; this is not a proof against all quotations or pretraining exposure. The first evaluation was a frozen external test. Subsequent correction-development protocols (Steps 19A-C) reuse ELR-A and are explicitly developmental. They can use different background pools from the first frozen comparison.

Sources: `sources.csv` gives titles, authors, Gutenberg IDs/URLs, raw hashes and attribution notes. `frozen_protocol.json` preserves original pre-scoring choices; `provenance/step19*_development_protocol.json` documents later reuse. Reconstructed prepared and reader-level document hashes are separately supplied. Citation: CDSAB plus source catalogue entries; preserve original source notices.
