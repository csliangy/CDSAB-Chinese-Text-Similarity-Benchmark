# HLR: Chinese Hierarchical Literary Relations

405 text views from 135 source excerpts, in three 45-excerpt sets and long/medium/short versions. There are 27 canonical books, 11 authors and four source categories. Long retains the checked excerpt; medium/short take the first half/fifth of source lines, not a fixed number of characters. The original preparation/audit records preserve the exact generation rule per text.

The 8,910 pairs are 990 unordered pairs in each of nine set/length groups. In each group cumulative shared-chapter/same-book/same-author/same-category positive counts are 24/84/198/270. The release retains all source descriptors and hierarchy flags. The primary retrieval task uses only 18 queries per group from three novels, with 3 disjoint-chapter positives and 12 same-author/different-book negatives. Four frozen query tasks yield 1,620 total records including ineligible queries; do not count them all as primary independent observations.

No official train/test split is invented. Earlier analyses reuse these records; they are development/within-corpus evidence. Length views and text pairs share sources. Same-book relevance is not a semantic-equivalence annotation. Dynasty is not a standardized field or evaluated target. HLR and NFR overlap in two eligible titles.

Public release: metadata, pair labels, query pools, source hashes and original preparation provenance. Narrative not included; exact authorized sources are required. Citation: CDSAB plus source attribution retained in metadata.
