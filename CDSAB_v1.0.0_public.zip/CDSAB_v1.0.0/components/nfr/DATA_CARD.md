# NFR: Chinese Novel Fragment Retrieval

Nine Jin Yong novels, 320 available chapter files, 180 selected chapters and 36 evaluated fragments. Each novel supplies four disjoint five-chapter windows at zero-based starts floor(i*(N-5)/3), i=0,1,2,3. No two selected fragments share a chapter. There are 54 same-book and 576 different-book unordered pairs; 36 retrieval queries each use 3 same-book positives and 32 negatives.

All works share an author. Retrieval tests work identity across nonoverlapping chapters; it does not isolate author style or gold semantic similarity. Two eligible titles also occur in HLR. NFR is therefore not an independent external test. The three stored evaluation folds apply to the original M3E fusion procedure; their complementary development books overlap, so the folds are not independent corpora.

The original chapter headings are excluded from scored bodies. Metadata preserve source byte hashes, exact chapter IDs and character spans. The release includes source metadata for all 320 chapters and the 36 document selectors, but no copyrighted narrative. Citation: CDSAB; source author Jin Yong remains explicitly acknowledged.
