# ELR-B: Chinese External Literary Retrieval B

Nine further Project Gutenberg works, eight catalogue-author groups, 494 source chapters, 36 disjoint five-chapter documents and 36 nested 1,500-nonspace-character excerpts. The Tianhuazangzhuren catalogue attribution is shared by two works. Original sources retain missing-glyph markers and documented transcription limitations.

Original parsing repairs include 93 heading separators in Feng Shen Yan Yi and an explicitly verified repeated chapter-four suffix removed from chapter five in Xing Shi Yin Yuan; only the duplicate suffix is removed after a normalized-content equivalence check. The unmodified originals remain included; parser code and structural audit record these operations. No narrative was reconstructed from a language model.

The first frozen evaluation tests the correction chosen on ELR-A. Three author-grouped rotations each hold out six works and use the other three for background statistics. Primary candidate pools have 3 same-book positives/20 negatives. Across both regimes there are 144 main query-pool records, plus 32 same-author diagnostic records (176 total). The rotations reuse documents and overlap; they are not independent test collections. See the frozen protocol for exact author assignments/background selections.

After that first comparison, ELR-B was reused for segmentation and graph sensitivity studies. These are exploratory controls, not additional untouched replications. Selected long windows do not share chapters, but excerpt views are intentionally nested. Overlap audits do not exclude paraphrases, training exposure or all transcription errors.

Citation: CDSAB and the original catalogue URLs in `sources.csv`. The public release includes all nine unmodified source books with notices and exact deterministic reconstruction recipes.
