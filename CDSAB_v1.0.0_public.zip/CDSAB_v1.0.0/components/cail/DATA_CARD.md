# CAIL2019-SCM and its CDSAB derivative

The original task chooses whether B or C is more similar to anchor legal case A. Preserve the original name and cite Xiao et al. (2019), arXiv:1911.08962. CDSAB does not claim creation of the official benchmark or new preference judgments.

| Variant | Train | Validation | Test | Role |
|---|---:|---:|---:|---|
| official | 5,102 | 1,500 | 1,536 | Original comparison; unchanged files |
| filtered | 5,068 | 1,481 | 1,237 | Construction intermediate; not scored |
| case_disjoint | 594 | 200 | 200 | Our smaller exact-text overlap-controlled evaluation |

The filtered intermediate removes 20 rows in ten contradictory comparison groups, 19 identity comparisons and 313 duplicate triplets; the original train/validation/test priority retains the first occurrence. The derivative uses the documented seed-42/SHA-256 selection: choose 200 filtered test rows, remove validation rows sharing compact-normalized cases, choose 200 eligible validation rows and retain 594 disjoint training rows. Several feasible holdout sizes were inspected before the construction was frozen. Original labels and split membership remain unchanged. Row selectors are authoritative for exact reproduction; the protocol is not a performance-optimized resampling.

Compact identity removes Unicode whitespace and preserves all other characters. Official train/validation/test unique case counts are 1,607/1,162/1,161, with pairwise intersections 1,134/1,135/1,002. The derivative has 376/369/427 unique cases and zero cross-split intersections. It does not guarantee different proceedings or semantic independence; within-split reuse remains. Its changed sample composition means performance differences from official data cannot be attributed only to overlap removal.

The archive contains original-row/case identifiers, labels, retention decisions, all split file hashes and reconstruction code. It excludes case prose. Obtain the official files upstream; every derivative can be reproduced byte-for-byte. Cite both Xiao et al. and CDSAB for the derivative, clearly described as author-constructed rather than an official CAIL split.
