#!/usr/bin/env python3
"""Verify release checksums, identifiers, qrels, split isolation and optional rebuilt texts."""
import argparse
import csv
import hashlib
import json
from collections import Counter
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def read(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))

def records(path):
    return [json.loads(s) for s in path.read_text(encoding='utf-8-sig').splitlines() if s.strip()]

def csvrows(path):
    with path.open(encoding='utf-8-sig', newline='') as stream:
        return list(csv.DictReader(stream))

def require(ok, message):
    if not ok:
        raise ValueError(message)

def verify(root=ROOT, reconstructed=None):
    lock = read(root / 'release_checksums.json')
    for name, digest in lock['files'].items():
        path = (root / name).resolve()
        require(path.is_relative_to(root.resolve()) and path.is_file(), 'Missing or unsafe release path: ' + name)
        require(sha(path) == digest, 'Release file changed: ' + name + '; restore the archive, do not rewrite its checksum')
    result = {'release_files_verified': len(lock['files']), 'components': {}}
    all_docs = []
    for key, count in [('hlr', 405), ('nfr', 36), ('elr_a', 72), ('elr_b', 72)]:
        component = root / 'components' / key
        docs = records(component / 'documents.jsonl')
        ids = {d['doc_id'] for d in docs}
        require(len(docs) == len(ids) == count, 'Wrong/duplicate document count: ' + key)
        require(all(d['dataset_id'] == 'cdsab_' + key for d in docs), 'Dataset ID mismatch')
        require(all('text' not in d for d in docs), 'Unexpected prose in public metadata')
        require(all(not d.get('parent_doc_id') or d['parent_doc_id'] in ids for d in docs), 'Missing parent document')
        queries = records(component / 'queries.jsonl')
        expected_qrels = []
        seen = set()
        for q in queries:
            qid = q['query_id']
            query_key = (q.get('rotation', ''), q.get('task', 'same_book'), q.get('group', q.get('regime', 'all')), qid)
            require(query_key not in seen, 'Duplicate query/pool identifier')
            seen.add(query_key)
            require(qid in ids, 'Query absent from metadata')
            candidates = q['candidates']
            cids = [c.get('doc_id', c.get('document_id')) for c in candidates]
            require(len(cids) == len(set(cids)) and qid not in cids and set(cids) <= ids, 'Invalid candidate pool')
            require(all(c['label'] in (0, 1) for c in candidates), 'Invalid qrel label')
            if q.get('eligible', True):
                require({c['label'] for c in candidates} == {0, 1}, 'Eligible query lacks positives or negatives')
            for c in candidates:
                expected_qrels.append((str(query_key[0]), query_key[1], query_key[2], qid,
                                       c.get('doc_id', c.get('document_id')), str(c['label'])))
        actual = csvrows(component / 'qrels.csv')
        require([(r['rotation'], r['task'], r['group'], r['query_id'], r['document_id'], r['relevance']) for r in actual] == expected_qrels, 'CSV qrels disagree with original frozen queries')
        rebuilt = 0
        if reconstructed is not None and (reconstructed / key).exists():
            for d in docs:
                path = reconstructed / key / 'documents' / (d['doc_id'] + '.txt')
                require(path.is_file() and sha(path) == d['text_sha256'], 'Reconstructed document changed: ' + d['doc_id'])
                rebuilt += 1
        all_docs.extend(docs)
        result['components'][key] = {'documents': count, 'query_pool_records': len(queries), 'qrels': len(actual), 'rebuilt_documents_verified': rebuilt}
    require(len({d['doc_id'] for d in all_docs}) == 585, 'Cross-component document ID collision')
    require(len(records(root / 'components/hlr/pairs.jsonl')) == 8910, 'HLR pair count')
    require(len(records(root / 'components/nfr/pairs.jsonl')) == 630, 'NFR pair count')
    nfr = records(root / 'components/nfr/documents.jsonl')
    chapters = [ch for d in nfr for ch in d['chapter_ids']]
    require(len(chapters) == len(set(chapters)) == 180, 'Shared NFR chapters')
    for key in ('elr_a', 'elr_b'):
        docs = records(root / f'components/{key}/documents.jsonl')
        for bid in {d['book_id'] for d in docs}:
            for regime in ('long', 'excerpt'):
                selected = [d for d in docs if d['book_id'] == bid and d['regime'] == regime]
                ids = [ch for d in selected for ch in d['chapter_ids']]
                require(len(selected) == 4 and len(ids) == len(set(ids)), 'Shared external windows')
    expected = {'official': [5102, 1500, 1536], 'filtered': [5068, 1481, 1237], 'case_disjoint': [594, 200, 200]}
    for variant, counts in expected.items():
        rows = csvrows(root / f'components/cail/{variant}_triplets.csv')
        require([sum(r['split'] == split for r in rows) for split in ('train', 'valid', 'test')] == counts, 'CAIL split counts changed')
        cases = csvrows(root / f'components/cail/{variant}_cases.csv')
        if variant == 'case_disjoint':
            require(all(len(json.loads(c['splits'])) == 1 for c in cases), 'CAIL derivative has cross-split case overlap')
        if reconstructed is not None and (reconstructed / 'cail').exists():
            source = read(root / 'provenance/cail_split_manifest.json')['variants'][variant]['splits']
            for split in ('train', 'valid', 'test'):
                path = reconstructed / 'cail' / variant / (split + '.json')
                require(path.is_file() and sha(path) == source[split]['sha256'], 'Reconstructed CAIL bytes changed')
    require(len(list((root / 'third_party/project_gutenberg').glob('*.txt'))) == 18, 'Upstream book count')
    return result

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--reconstructed', type=Path)
    args = parser.parse_args()
    result = verify(ROOT, args.reconstructed)
    print(json.dumps(result, indent=2))
    print('[PASS] Release checks passed. No model scores computed.')

if __name__ == '__main__':
    main()
