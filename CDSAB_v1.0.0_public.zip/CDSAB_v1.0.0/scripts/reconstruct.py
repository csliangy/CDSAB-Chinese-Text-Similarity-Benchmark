#!/usr/bin/env python3
"""Reconstruct checked CDSAB texts locally, without network access or model inference."""
import argparse
import csv
import hashlib
import importlib.util
import importlib.metadata
import json
import re
import shutil
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
COMPONENTS = ('hlr', 'nfr', 'elr_a', 'elr_b', 'cail')

def sha(data):
    return hashlib.sha256(data).hexdigest()

def read(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))

def records(path):
    return [json.loads(line) for line in path.read_text(encoding='utf-8-sig').splitlines() if line.strip()]

def require(ok, message):
    if not ok:
        raise ValueError(message)

def checked(path, expected):
    require(path.is_file(), 'Missing source: ' + str(path))
    raw = path.read_bytes()
    require(sha(raw) == expected, 'Source changed: ' + str(path) + '; restore the checked input, do not rewrite the checksum')
    return raw

def write(path, text):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(text.encode('utf-8'))  # Explicit LF; identical on Windows/Linux.

def vendor(name):
    spec = importlib.util.spec_from_file_location(name, ROOT / 'scripts/vendor' / (name + '.py'))
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module

def external(key, out):
    require(importlib.metadata.version('opencc-python-reimplemented') == '0.1.7', 'Install opencc-python-reimplemented==0.1.7')
    from opencc import OpenCC
    cc = OpenCC('t2s')
    module = vendor('build_elr_a_original' if key == 'elr_a' else 'build_elr_b_original')
    config = read(ROOT / f'components/{key}/source_config.json')
    sources = config['books'] if isinstance(config, dict) else config
    prepared = out / key / 'prepared'
    for source in sources:
        raw = checked(ROOT / f'third_party/project_gutenberg/{source["ebook_id"]}.txt', source['raw_sha256'])
        units = module.split(raw, source['expected_chapters']) if key == 'elr_a' else module.parse_chapters(source, raw)[0]
        bid = source['book_id']
        bodies = []
        for number, heading, body in units:
            converted = cc.convert(body)
            write(prepared / f'chapters/{bid}/{number:03d}.txt', converted + '\n')
            bodies.append(converted if key == 'elr_a' else converted + '\n')
        starts = [i * (len(units) - 5) // 3 for i in range(4)]
        require(len({j for start in starts for j in range(start, start + 5)}) == 20, 'Shared source chapters')
        for window, start in enumerate(starts, 1):
            if key == 'elr_a':
                count = 0
                for pos, char in enumerate(bodies[start]):
                    count += not char.isspace()
                    if count == 1500:
                        prefix = bodies[start][:pos + 1]
                        break
                else:
                    raise ValueError('Short excerpt source')
                write(prepared / f'documents/excerpt/{bid}_w{window}_excerpt.txt', prefix + '\n')
                write(prepared / f'documents/long/{bid}_w{window}_long.txt', '\n\n'.join(bodies[start:start + 5]) + '\n')
            else:
                write(prepared / f'excerpts/{bid}/{window:02d}.txt', module.prefix_nonspace(bodies[start]))
    expected = read(ROOT / f'components/{key}/prepared_text_checksums.json')
    actual_paths = {p.relative_to(prepared).as_posix() for p in prepared.rglob('*.txt')}
    require(actual_paths == set(expected), key + ': prepared file set changed')
    for name, digest in expected.items():
        checked(prepared / name, digest)
    docs = records(ROOT / f'components/{key}/documents.jsonl')
    for doc in docs:
        if key == 'elr_a':
            text = (prepared / doc['relative_path']).read_text(encoding='utf-8').strip()
        else:
            text = '\n'.join((prepared / p).read_text(encoding='utf-8') for p in doc['segment_paths'])
        require(sha(text.encode()) == doc['text_sha256'], 'Scored text changed: ' + doc['doc_id'])
        write(out / key / 'documents' / (doc['doc_id'] + '.txt'), text)
    return {'documents': len(docs), 'prepared_files_byte_exact': len(expected)}

def private(key, source, out):
    require(source is not None and source.is_dir(), '--private-dataset-root must point to your authorized checked Dataset directory')
    docs = records(ROOT / f'components/{key}/documents.jsonl')
    for doc in docs:
        if key == 'hlr':
            raw = checked(source / doc['relative_path'], doc['source_file_sha256'])
            text = raw.decode(doc['encoding']).replace('\r\n', '\n').replace('\r', '\n')
        else:
            parts = []
            for chapter in doc['chapters']:
                raw = checked(source / chapter['source_relative_path'], chapter['source_sha256'])
                decoded = raw.decode('utf-8-sig').replace('\r\n', '\n').replace('\r', '\n')
                lines = decoded.split('\n', 1)
                require(len(lines) == 2, 'Chapter has no body')
                body = lines[1].strip()
                require(len(body) == chapter['char_end'] - chapter['char_start'], 'Chapter span changed')
                parts.append(body)
            text = '\n\n'.join(parts)
        require(sha(text.encode()) == doc['text_sha256'], 'Scored text changed: ' + doc['doc_id'])
        write(out / key / 'documents' / (doc['doc_id'] + '.txt'), text)
    return {'documents': len(docs), 'all_source_and_document_hashes_verified': True}

def cail(source, out):
    require(source is not None and source.is_dir(), '--cail-root must point to the official directory containing train.json, valid.json and test.json')
    manifest = read(ROOT / 'provenance/cail_split_manifest.json')['variants']
    selectors = records(ROOT / 'components/cail/row_manifest.jsonl')
    counts = {}
    for split in ('train', 'valid', 'test'):
        raw = checked(source / (split + '.json'), manifest['official']['splits'][split]['sha256'])
        original = [json.loads(line) for line in raw.decode('utf-8-sig').splitlines() if line.strip()]
        rows = [r for r in selectors if r['source_split'] == split]
        require(len(original) == len(rows), 'CAIL row count changed')
        for row in rows:
            item = original[row['source_line'] - 1]
            require(item['label'] == row['original_label'], 'CAIL label changed')
            for field, digest in row['case_ids'].items():
                require(sha(re.sub(r'\s+', '', item[field]).encode()) == digest, 'CAIL case identity changed')
        for variant in ('official', 'filtered', 'case_disjoint'):
            selected = [(r['source_line'] if variant == 'official' else r[variant]['output_line'], original[r['source_line'] - 1])
                        for r in rows if variant == 'official' or r[variant]['retained']]
            text = ''.join(json.dumps(item, ensure_ascii=False) + '\n' for _, item in sorted(selected))
            require(sha(text.encode()) == manifest[variant]['splits'][split]['sha256'], 'CAIL derivative bytes changed')
            write(out / 'cail' / variant / (split + '.json'), text)
            counts[variant + '/' + split] = len(selected)
    return counts

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--components', nargs='+', choices=COMPONENTS, default=['elr_a', 'elr_b'])
    parser.add_argument('--output', type=Path, required=True, help='A NEW output directory; existing directories are never overwritten')
    parser.add_argument('--private-dataset-root', type=Path)
    parser.add_argument('--cail-root', type=Path)
    args = parser.parse_args()
    from verify_release import verify
    verify(ROOT)
    destination = args.output.resolve()
    require(not destination.exists(), 'Output already exists; choose a new --output directory')
    destination.parent.mkdir(parents=True, exist_ok=True)
    temporary = Path(tempfile.mkdtemp(prefix='cdsab-reconstruct-', dir=destination.parent))
    report = {'version': '1.0.0', 'network_access': False, 'model_scores_computed': False, 'components': {}}
    try:
        for key in dict.fromkeys(args.components):
            if key.startswith('elr_'):
                result = external(key, temporary)
            elif key == 'cail':
                result = cail(args.cail_root, temporary)
            else:
                result = private(key, args.private_dataset_root, temporary)
            report['components'][key] = result
            print('[VERIFIED]', key, json.dumps(result))
        write(temporary / 'reconstruction_report.json', json.dumps(report, indent=2) + '\n')
        temporary.rename(destination)
    except BaseException:
        shutil.rmtree(temporary, ignore_errors=True)
        raise
    print('[DONE]', destination)

if __name__ == '__main__':
    main()
