#!/usr/bin/env python3
"""Prepare the checked Books, Jin Yong and CAIL inputs. Python 3.10+, stdlib only.

Run: python Scripts/01_prepare_datasets.py
Defaults resolve relative to this script, independently of the working directory.
Source files are read only. Existing verified output is reused; other output is
never overwritten. See README_step01.md for the protocol and schema.
"""
from __future__ import annotations

import argparse
from collections import Counter
import csv
import hashlib
from itertools import combinations
import json
from pathlib import Path, PurePosixPath
import re
import shutil
import sys
import tempfile

VERSION = 'step01-v1'
PROJECT_ROOT = Path(__file__).resolve().parent.parent
BOOKS = {
    '1SheDiao': ('射雕英雄传', 'book_jinyong_shediao', 40),
    '2ShenDiao': ('神雕侠侣', 'book_jinyong_shendiao', 40),
    '3XiaoAo': ('笑傲江湖', 'book_jinyong_xiaoao', 40),
    '4TianLong': ('天龙八部', 'book_jinyong_tianlong', 50),
    '5ShuJian': ('书剑恩仇录', 'book_jinyong_shujian', 20),
    '6BiXue': ('碧血剑', 'book_jinyong_bixue', 20),
    '7XiaKe': ('侠客行', 'book_jinyong_xiake', 20),
    '8LuDing': ('鹿鼎记', 'book_jinyong_luding', 50),
    '9YiTian': ('倚天屠龙记', 'book_jinyong_yitian', 40),
}


def require(ok, message):
    if not ok:
        raise ValueError(message)


def sha256(raw):
    return hashlib.sha256(raw).hexdigest()


def compact(text):
    return re.sub(r'\s+', '', text)


def lf(text):
    return text.replace('\r\n', '\n').replace('\r', '\n')


def read_json(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))


def read_csv(path):
    with path.open(encoding='utf-8-sig', newline='') as handle:
        return list(csv.DictReader(handle))


def write_json(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf-8', newline='\n')


def write_jsonl(path, rows):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('w', encoding='utf-8', newline='\n') as handle:
        for row in rows:
            handle.write(json.dumps(row, ensure_ascii=False, separators=(',', ':')) + '\n')


def under(root, relative):
    relative_path = PurePosixPath(relative)
    require(not relative_path.is_absolute() and '..' not in relative_path.parts and '\\' not in relative,
            'Invalid relative path: ' + relative)
    path = root.joinpath(*relative_path.parts)
    require(path.resolve().is_relative_to(root.resolve()), 'Path escapes dataset root: ' + relative)
    return path


def verify_inputs(dataset_root, lock):
    require(dataset_root.is_dir(), 'Dataset folder not found: ' + str(dataset_root))
    expected = lock['files']
    canonical = json.dumps(expected, ensure_ascii=False, sort_keys=True, separators=(',', ':')).encode('utf-8')
    require(len(expected) == lock['file_count'] and sha256(canonical) == lock['corpus_fingerprint'],
            'Invalid dataset lock manifest')
    errors = []
    for name, expected_hash in expected.items():
        path = under(dataset_root, name)
        if not path.is_file():
            errors.append('Missing: ' + name)
        elif sha256(path.read_bytes()) != expected_hash:
            errors.append('Changed: ' + name)
    active_folders = ['Books', 'Chapters', 'CAIL2019-SCM', 'CAIL2019-SCM_filtered']
    for folder in active_folders:
        for path in (dataset_root / folder).rglob('*'):
            if path.is_file() and path.suffix.lower() in {'.txt', '.json', '.jsonl', '.csv', '.xlsx'}:
                name = path.relative_to(dataset_root).as_posix()
                if name not in expected:
                    errors.append('Unexpected data file: ' + name)
    require(not errors, 'Dataset differs from the checked release. Extract the final ZIP into a fresh folder.\n'
            + '\n'.join(errors[:15]) + (f'\n... {len(errors)} issues total' if len(errors) > 15 else ''))
    print(f'[INPUT] Verified {len(expected)} files against the checked release.', flush=True)


def unit_relation(a, b):
    a, b = set(a), set(b)
    if not a or not b:
        return None
    if a.isdisjoint(b):
        return 0
    return 1 if len(a) == len(b) == 1 else None


def prepare_books(dataset_root, output):
    rows = read_csv(dataset_root / 'Books/books_metadata.csv')
    require(len(rows) == 405 and len({r['document_id'] for r in rows}) == 405, 'Invalid Books document IDs')
    documents = []
    for row in sorted(rows, key=lambda r: r['document_id']):
        raw = under(dataset_root, row['relative_path']).read_bytes()
        require(sha256(raw) == row['sha256'], 'Book text/metadata mismatch: ' + row['document_id'])
        text = raw.decode(row['encoding'], errors='strict')
        require(text.strip() and '\ufffd' not in text and '\x00' not in text, 'Invalid book text')
        record = dict(row)
        record.update(doc_id=row['document_id'], dataset_id='books')
        for key in ['chapter_ids', 'section_ids']:
            record[key] = json.loads(row[key])
        for key in ['bytes', 'characters_nonspace', 'line_count']:
            record[key] = int(row[key])
        for key in ['is_prefix_of_long', 'generation_rule_verified']:
            record[key] = bool(int(row[key]))
        documents.append(record)
    write_jsonl(output / 'Books/documents.jsonl', documents)
    pairs, group_summaries = [], []
    for set_id in ['set1', 'set2', 'set3']:
        for length in ['long', 'medium', 'short']:
            group = [r for r in documents if r['set_id'] == set_id and r['length'] == length]
            require(len(group) == 45, 'Books group must contain 45 documents')
            counts = Counter()
            for a, b in combinations(group, 2):
                labels = {f'same_{key}': int(a[f'{key}_id'] == b[f'{key}_id']) for key in ['category','author','book']}
                labels['same_chapter'] = unit_relation(a['chapter_ids'], b['chapter_ids'])
                require(labels['same_chapter'] is not None, 'Unexpected ambiguous chapter label')
                labels['same_section'] = unit_relation(a['section_ids'], b['section_ids'])
                deepest = next((key for key in ['same_chapter','same_book','same_author','same_category'] if labels[key] == 1), 'different_category')
                counts[deepest] += 1
                pairs.append(dict(dataset_id='books', set_id=set_id, length=length,
                                  doc_i=a['doc_id'], doc_j=b['doc_id'], **labels, deepest_relation=deepest))
            require(dict(counts) == {'same_chapter':24,'same_book':60,'same_author':114,'same_category':72,'different_category':720},
                    'Unexpected Books hierarchy counts')
            group_summaries.append(dict(set_id=set_id, length=length, documents=45, pairs=990, exclusive_relation_counts=dict(counts)))
    require(len(pairs) == 8910, 'Books pair count')
    write_jsonl(output / 'Books/pairs.jsonl', pairs)
    print('[BOOKS] 405 documents; 135 source excerpts; 8,910 within-set/length pairs.', flush=True)
    return {'documents':405,'source_excerpts':135,'pairs':len(pairs),'groups':group_summaries}


def choose_starts(n_chapters, width=5, count=4):
    require(width > 0 and count > 0 and n_chapters >= width * count,
            'Insufficient chapters for disjoint windows')
    starts = [0] if count == 1 else [(i * (n_chapters - width)) // (count - 1) for i in range(count)]
    require(all(b >= a + width for a,b in zip(starts, starts[1:])), 'Overlapping windows')
    return starts


def heading_number(title):
    m = re.match(r'第([零〇一二三四五六七八九十两]+)回|([零〇一二三四五六七八九十两]+)\s', title)
    require(m is not None, 'Unrecognized chapter title: ' + title)
    value = m.group(1) or m.group(2)
    digits = dict(zip('零一二三四五六七八九', range(10)))
    digits.update({'〇':0,'两':2})
    if '十' in value:
        a,b = value.split('十')
        return (digits[a] if a else 1)*10 + (digits[b] if b else 0)
    return digits[value]


def prepare_jinyong(dataset_root, output):
    summary = read_json(dataset_root / 'Chapters/chapter_split_summary.json')
    require(len(summary) == 9 and {s['book_id'] for s in summary} == set(BOOKS), 'Unexpected chapter book list')
    documents, selection = [], []
    selected_chapter_ids = []
    for item in sorted(summary, key=lambda s: s['book_id']):
        code = item['book_id']
        title, book_id, expected_count = BOOKS[code]
        folder = under(dataset_root, item['out_dir'])
        meta = read_json(folder / f'{code}_chapters_meta.json')
        require(expected_count == item['n_chapters'] == meta['n_chapters'] == len(meta['chapters']), 'Chapter count mismatch: ' + code)
        require(sorted(p.name for p in folder.glob('*.txt')) == [c['file'] for c in meta['chapters']], 'Chapter file list mismatch')
        chapters = []
        for i, entry in enumerate(meta['chapters'], 1):
            source_path = item['out_dir'].rstrip('/') + '/' + entry['file']
            raw = under(dataset_root, source_path).read_bytes()
            text = lf(raw.decode('utf-8', errors='strict'))
            require('\n' in text, 'Chapter body missing')
            heading, body = text.split('\n', 1)
            require(entry['chapter_idx'] == i and entry['file'] == f'{code}_{i:03d}.txt', 'Chapter index mismatch')
            require(heading.strip() == entry['title'] and heading_number(heading.strip()) == i and len(text) == entry['chars'], 'Chapter metadata mismatch')
            body = body.strip()
            require(body and '\ufffd' not in body and '\x00' not in body, 'Invalid chapter body')
            chapters.append(dict(chapter_idx=i, chapter_id=f'{book_id}__ch{i:03d}',
                                 source_relative_path=source_path, source_sha256=sha256(raw),
                                 heading=heading.strip(), body=body))
        starts = choose_starts(len(chapters))
        ranges = []
        for excerpt_idx, start in enumerate(starts, 1):
            block = chapters[start:start+5]
            text = '\n\n'.join(c['body'] for c in block)
            spans, offset = [], 0
            for chapter in block:
                span = {k:v for k,v in chapter.items() if k != 'body'}
                span.update(char_start=offset, char_end=offset+len(chapter['body']))
                spans.append(span)
                require(text[span['char_start']:span['char_end']] == chapter['body'], 'Chapter span mismatch')
                offset = span['char_end'] + 2
            doc_id = f'jinyong_{code}_E{excerpt_idx:02d}'
            chapter_ids = [c['chapter_id'] for c in block]
            selected_chapter_ids.extend(chapter_ids)
            documents.append(dict(dataset_id='jinyong_nonoverlap_v1', doc_id=doc_id,
                                  book_id=book_id, book_code=code, book_title=title, author_id='author_jinyong',
                                  excerpt_id=f'E{excerpt_idx:02d}', chapter_start=block[0]['chapter_idx'],
                                  chapter_end=block[-1]['chapter_idx'], chapter_ids=chapter_ids,
                                  chapters=spans, text=text, text_sha256=sha256(text.encode('utf-8')),
                                  characters=len(text), characters_nonspace=len(compact(text))))
            ranges.append(dict(doc_id=doc_id, chapter_start=block[0]['chapter_idx'], chapter_end=block[-1]['chapter_idx']))
        used = {i for start in starts for i in range(start+1,start+6)}
        selection.append(dict(book_code=code, book_id=book_id, book_title=title, total_chapters=len(chapters),
                              selected_chapters=len(used), unused_chapter_indices=sorted(set(range(1,len(chapters)+1))-used), ranges=ranges))
        print(f'[CHAPTERS] {code}: ' + ', '.join(f"{r['chapter_start']}-{r['chapter_end']}" for r in ranges), flush=True)
    require(len(documents) == 36 and len(selected_chapter_ids) == len(set(selected_chapter_ids)) == 180,
            'Selected chapter reuse or incorrect document count')
    require(len({compact(d['text']) for d in documents}) == len(documents), 'Duplicate complete fragment')
    pairs = []
    for a,b in combinations(documents,2):
        shared = sorted(set(a['chapter_ids']) & set(b['chapter_ids']))
        require(not shared, 'Shared chapter between fragments')
        pairs.append(dict(dataset_id='jinyong_nonoverlap_v1',doc_i=a['doc_id'],doc_j=b['doc_id'],
                          same_book=int(a['book_id']==b['book_id']),shared_chapter_count=len(shared)))
    positive = sum(p['same_book'] for p in pairs)
    require(len(pairs) == 630 and positive == 54, 'Jin Yong pair counts')
    write_jsonl(output / 'JinYong/documents.jsonl', documents)
    write_jsonl(output / 'JinYong/pairs.jsonl', pairs)
    write_json(output / 'JinYong/selection.json', selection)
    print('[JINYONG] 36 fragments; 54 same-book + 576 different-book pairs; 0 shared chapters.', flush=True)
    return dict(documents=36,pairs=630,same_book_pairs=54,different_book_pairs=576,
                source_chapters=320,selected_chapters=180,unused_chapters=140,
                shared_chapters=0,whole_fragment_duplicates_after_whitespace_removal=0,
                min_characters_nonspace=min(d['characters_nonspace'] for d in documents),
                max_characters_nonspace=max(d['characters_nonspace'] for d in documents))


def prepare_cail(dataset_root, output):
    specifications = [
        ('official','CAIL2019-SCM',(5102,1500,1536)),
        ('filtered','CAIL2019-SCM_filtered/filtered',(5068,1481,1237)),
        ('case_disjoint','CAIL2019-SCM_filtered/case_disjoint',(594,200,200)),
    ]
    variants = {}
    for variant, folder, expected_counts in specifications:
        cases, splits = {}, {}
        for split, expected_count in zip(['train','valid','test'],expected_counts):
            relative_path = f'{folder}/{split}.json'
            raw = under(dataset_root,relative_path).read_bytes()
            lines = raw.decode('utf-8', errors='strict').splitlines()
            require(len(lines) == expected_count and all(line.strip() for line in lines), 'CAIL row count or blank line')
            labels = Counter()
            cases[split] = set()
            for line in lines:
                row = json.loads(line)
                require(set(row) == {'A','B','C','label'} and row['label'] in ('B','C'), 'Invalid CAIL schema')
                for key in 'ABC':
                    require(isinstance(row[key],str) and row[key].strip(), 'Empty CAIL case')
                    cases[split].add(sha256(compact(row[key]).encode('utf-8')))
                labels[row['label']] += 1
            splits[split] = dict(relative_path=relative_path,rows=len(lines),label_counts=dict(labels),
                                 unique_case_texts=len(cases[split]),sha256=sha256(raw))
        overlap = {f'{a}__{b}':len(cases[a]&cases[b]) for a,b in combinations(['train','valid','test'],2)}
        if variant == 'case_disjoint':
            require(not any(overlap.values()), 'Strict CAIL split overlap')
        variants[variant] = dict(splits=splits,shared_normalized_case_texts_across_splits=overlap)
        print(f'[CAIL] {variant}: train/valid/test = ' + '/'.join(str(n) for n in expected_counts), flush=True)
    result = dict(format='jsonl',encoding='utf-8',task='choose_B_or_C_given_anchor_A',
                  normalization_for_overlap_only='remove Unicode whitespace; preserve all other characters',variants=variants)
    write_json(output / 'CAIL/manifest.json', result)
    return result


def verify_existing(output, identity):
    manifest_path = output / 'manifest.json'
    require(manifest_path.is_file(), 'Output already exists without a valid manifest; choose a new --output-root.')
    manifest = read_json(manifest_path)
    require(manifest['identity'] == identity, 'Output belongs to a different input/script version; choose a new --output-root.')
    expected = manifest['outputs']
    actual = {p.relative_to(output).as_posix() for p in output.rglob('*') if p.is_file()}
    require(actual == set(expected)|{'manifest.json'}, 'Prepared output has missing or extra files; choose a new --output-root.')
    for relative, record in expected.items():
        require(sha256(under(output,relative).read_bytes()) == record['sha256'], 'Prepared file has changed: ' + relative)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--dataset-root',type=Path,default=PROJECT_ROOT/'Dataset')
    parser.add_argument('--output-root',type=Path,default=PROJECT_ROOT/'Prepared/step01')
    parser.add_argument('--verify-only',action='store_true',help='Verify the input release without creating outputs')
    args = parser.parse_args()
    dataset_root, output = args.dataset_root.resolve(), args.output_root.resolve()
    require(not output.is_relative_to(dataset_root) and not dataset_root.is_relative_to(output),
            'Prepared output must be separate from the Dataset directory')
    lock_path = Path(__file__).resolve().parent/'config/dataset_lock.json'
    require(lock_path.is_file(), 'Missing config/dataset_lock.json. Extract the complete Scripts package.')
    lock = read_json(lock_path)
    verify_inputs(dataset_root,lock)
    if args.verify_only:
        return
    identity = dict(pipeline_version=VERSION,input_release=lock['release'],
                    corpus_fingerprint=lock['corpus_fingerprint'],script_sha256=sha256(Path(__file__).read_bytes()),
                    protocol=dict(chapters_per_fragment=5,fragments_per_book=4,
                                  zero_based_start_rule='floor(i*(N-5)/3), i=0,1,2,3',
                                  chapter_text='UTF-8 strict; LF newlines; remove first heading line; strip boundary whitespace; join bodies with two LF',
                                  books_text='read original source using per-row encoding; no text rewriting',
                                  cail_text='reference original variant files; no text or label rewriting'))
    if output.exists():
        verify_existing(output,identity)
        print('[REUSE] Existing prepared files match this input and script.',flush=True)
        print('[OUTPUT] ' + str(output),flush=True)
        return
    output.parent.mkdir(parents=True,exist_ok=True)
    temporary = Path(tempfile.mkdtemp(prefix='step01-build-',dir=output.parent))
    try:
        books = prepare_books(dataset_root,temporary)
        jinyong = prepare_jinyong(dataset_root,temporary)
        cail = prepare_cail(dataset_root,temporary)
        result = dict(pipeline_version=VERSION,corpus_fingerprint=lock['corpus_fingerprint'],
                      books=books,jinyong=jinyong,cail_split_rows={k:{s:v['rows'] for s,v in info['splits'].items()} for k,info in cail['variants'].items()},
                      model_experiments_run=False,
                      interpretation='Source relationships and preparation checks only; no semantic accuracy or superiority claim.')
        write_json(temporary/'summary.json',result)
        outputs = {p.relative_to(temporary).as_posix():dict(sha256=sha256(p.read_bytes()),bytes=p.stat().st_size)
                   for p in sorted(temporary.rglob('*')) if p.is_file()}
        write_json(temporary/'manifest.json',dict(identity=identity,outputs=outputs))
        verify_existing(temporary,identity)
        temporary.rename(output)
    finally:
        if temporary.exists():
            shutil.rmtree(temporary)
    print('[DONE] Step 01 preparation completed; no model scores computed.',flush=True)
    print('[OUTPUT] ' + str(output),flush=True)


if __name__ == '__main__':
    try:
        main()
    except (ValueError, OSError, KeyError, UnicodeError, csv.Error) as error:
        print('[ERROR] ' + str(error),file=sys.stderr)
        sys.exit(1)
