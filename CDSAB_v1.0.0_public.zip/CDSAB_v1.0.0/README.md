# Chinese Document Similarity and Alignment Benchmark (CDSAB)

Version 1.0.0 · Prepared 21 September 2026 · Repository DOI not yet assigned

CDSAB organizes the checked inputs, source-relation labels and frozen candidate pools used in the accompanying Chinese document-similarity study. It compares representation and aggregation choices across different relevance targets. This release gives existing components consistent names; it introduces no new human semantic-similarity judgments and changes no experiment texts, labels or splits.

| Component | Full name | Scope | Public text access |
|---|---|---|---|
| HLR | Chinese Hierarchical Literary Relations | 405 documents; 135 source excerpts; 27 books; 11 authors; 3 sets × 3 nested length views; 8,910 within-group pairs | Metadata, source hashes and reconstruction code; authorized checked excerpts required |
| NFR | Chinese Novel Fragment Retrieval | 36 disjoint five-chapter fragments from 9 Jin Yong novels; 630 pairs | Metadata, chapter selectors and reconstruction code; authorized checked chapters required |
| ELR-A | Chinese External Literary Retrieval A | 9 works, 8 catalogue-author groups, 663 source chapters; 36 long documents + 36 nested excerpts | Nine unmodified Project Gutenberg books included; exact derived texts reconstruct locally |
| ELR-B | Chinese External Literary Retrieval B | 9 other works, 8 catalogue-author groups, 494 source chapters; 36 long documents + 36 nested excerpts | Nine unmodified Project Gutenberg books included; exact derived texts reconstruct locally |
| CAIL2019-SCM (official) | Original Similar Case Matching benchmark | 5,102 / 1,500 / 1,536 train / validation / test triplets | Obtain official prose upstream; selectors and labels included |
| CAIL2019-SCM (case-disjoint) | Our exact-text-disjoint derivative of CAIL2019-SCM | 594 / 200 / 200 triplets | Reconstruct from official files and supplied selectors |
| CAIL2019-SCM (filtered intermediate) | Intermediate in derivative construction | 5,068 / 1,481 / 1,237 triplets; **not scored** | Reconstruct for audit purposes |

These are separate task components, not one pooled training set or one accuracy leaderboard. Their units, relevance targets, dependence and candidate pools differ. The two CAIL evaluation variants are not independent datasets.

## What to upload

Upload this entire release archive to the dataset record. It contains all metadata and the 18 unmodified Gutenberg source books, retaining their embedded notices. It does **not** contain the HLR/NFR narrative files or CAIL case prose. Do not silently add those files under the metadata license. See `LICENSES.md` for scope and `DEPOSIT_GUIDE.md` for draft citation/DOI instructions. The manuscript research-results ZIP is a different artifact; it is not a substitute for this public dataset package.

## Verify and reconstruct

Python 3.10 or newer. Run inside the extracted `CDSAB_v1.0.0` directory. Verification uses only Python's standard library. Reconstruction of ELR-A/B also needs the pinned OpenCC conversion package:

```console
python scripts/verify_release.py
python -m pip install -r requirements.txt
python scripts/reconstruct.py --output ../CDSAB_reconstructed
python scripts/verify_release.py --reconstructed ../CDSAB_reconstructed
```

The default reconstruction creates the 144 external documents and their chapter/excerpt files. It performs no downloads, model inference or fitting. It checks every upstream source, all prepared-text hashes and every scored document hash. Choose a **new** output directory: the script refuses to overwrite existing data and removes incomplete temporary output on failure. All output text files use explicit UTF-8/LF on Windows and Linux.

To reconstruct HLR and NFR from your already-authorized, exact checked release:

```console
python scripts/reconstruct.py --components hlr nfr --private-dataset-root "D:/Main/Python-projects/alignment-guided-text-similarity/Dataset" --output ../CDSAB_private_reconstructed
```

A different edition of a novel is not a byte-equivalent substitute. If you do not have those checked sources, the public metadata describe the benchmark but do not reproduce its HLR/NFR scores. The included original preparation script in `provenance/` records the prior experiment workflow; the supported release entry point is `scripts/reconstruct.py`.

For CAIL, obtain the source from the [official project](https://github.com/china-ai-law-challenge/CAIL2019/tree/master/scm) ([original download](https://cail.oss-cn-qingdao.aliyuncs.com/cail2019/CAIL2019-SCM.zip)). Extract it and pass the directory directly containing `train.json`, `valid.json`, and `test.json`:

```console
python scripts/reconstruct.py --components cail --cail-root ../CAIL2019-SCM --output ../CDSAB_cail_reconstructed
```

This recreates all nine official/intermediate/derivative split files byte-for-byte from the checked original release. A source mismatch is a reason to inspect the release version, not to regenerate the expected hashes. Official upstream availability and file contents can change; the supplied hashes identify the evaluated version.

## Programming interface

`dataset_registry.csv` maps persistent component IDs, display names and legacy names. `literary_documents.csv` is the unified 585-document index; `literary_works.csv` lists all 54 component/work records with source attribution (works shared across components are not new independent works). Each `components/<name>/documents.jsonl` supplies complete component metadata, original IDs and canonical text hashes. Parse JSONL for array-valued hierarchy/spans; arrays in CSV cells are serialized JSON.

Canonical reconstructed literary files are `<output>/<component>/documents/<doc_id>.txt`. ELR-A/B also retain their original prepared chapter/excerpt tree under `<output>/<component>/prepared/`. CAIL output is `<output>/cail/<variant>/<split>.json` (one triplet per line). Do not rename original IDs or folders in an existing experiment checkout: this release provides display-name aliases, not an incompatible migration of the prior `Dataset`, `ExternalValidation`, or `ExternalValidation2` directories.

```python
import json
from pathlib import Path
release = Path('CDSAB_v1.0.0')
docs = [json.loads(line) for line in
        (release / 'components/hlr/documents.jsonl').read_text(encoding='utf-8').splitlines()]
same_author = docs[0]['author_id'] == docs[1]['author_id']
same_book = docs[0]['book_id'] == docs[1]['book_id']
shared_chapter = bool(set(docs[0]['chapter_ids']) & set(docs[1]['chapter_ids']))
```

Use the frozen `queries.jsonl`/`qrels.csv` for reported retrieval experiments; recreating candidate pools from these example equality checks can change the task. See `DATA_DICTIONARY.md` and the component cards for details.

## Evaluation and independence

- HLR length views are nested; group resampling by source/work, not by individual text pairs. Its primary no-shared-chapter/same-author task has only three eligible novels and 162 nested query records.
- NFR has no shared selected chapters, but two titles overlap HLR. It is not an independent external test of HLR findings.
- ELR-A was initially a frozen external validation and was later reused for correction development. ELR-B was initially a frozen external test of that correction and was later reused for segmentation/graph exploration. Preserve this chronology; later analyses are not additional untouched tests.
- Excerpts are nested within long documents in both external components. ELR-B's three background rotations overlap; they are not three independent corpora.
- Literary relevance means a specified source relationship, not an independently judged semantic-equivalence score. CAIL retains its original legal preference labels.
- CAIL case-disjoint means no identical case text across splits after removing Unicode whitespace only. It does not prove distinct legal proceedings, absence of paraphrases, or independence within a split.
- Source audits screen specified exact and fingerprint overlap; they do not establish absence of quotations, model-pretraining exposure or all transcription defects.

## Citation

Cite CDSAB for the new packaging, protocols and derivative construction, and cite Xiao et al. (2019) whenever using CAIL. `CITATION.cff` and `dataset_references.bib` contain the draft release citation and original CAIL citation. Source-level Gutenberg URLs and hashes are listed in each external `sources.csv`; cite/acknowledge those sources and preserve their notices when sharing. **No DOI or repository URL is claimed before deposit.**
